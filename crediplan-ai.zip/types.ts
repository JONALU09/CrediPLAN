export interface CreditCard {
  id: string;
  name: string;
  bank: string;
  limit: number;
  cutoffDay: number; // Day of the month (1-31)
  dueDay: number; // Day of the month (1-31)
  color: string;
}

export interface PaymentRecord {
  id: string;
  cardId: string;
  amount: number;
  month: number; // 0-11
  year: number;
  isPaid: boolean;
  notes?: string;
}

export interface PaymentWithCard extends PaymentRecord {
  card: CreditCard;
}

export type ViewState = 'dashboard' | 'calendar' | 'cards';

export const BANK_COLORS = [
  'bg-blue-500',
  'bg-red-500',
  'bg-emerald-500',
  'bg-purple-500',
  'bg-orange-500',
  'bg-slate-800',
  'bg-indigo-600',
  'bg-pink-600',
];