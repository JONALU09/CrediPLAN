import { GoogleGenAI } from "@google/genai";
import { CreditCard, PaymentRecord } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getFinancialAdvice = async (
  cards: CreditCard[],
  payments: PaymentRecord[]
): Promise<string> => {
  try {
    const today = new Date();
    
    // Prepare context for the AI
    const financialContext = {
      currentDate: today.toDateString(),
      cards: cards.map(c => ({
        name: c.name,
        bank: c.bank,
        limit: c.limit,
        cutoffDay: c.cutoffDay,
        dueDay: c.dueDay
      })),
      payments: payments.map(p => {
        const card = cards.find(c => c.id === p.cardId);
        return {
          cardName: card?.name || 'Unknown',
          amount: p.amount,
          isPaid: p.isPaid,
          status: p.isPaid ? "Paid" : "Pending"
        };
      })
    };

    const prompt = `
      Actúa como un asesor financiero personal experto en tarjetas de crédito.
      Analiza la siguiente situación financiera del usuario (en formato JSON implícito):
      ${JSON.stringify(financialContext, null, 2)}

      Genera un consejo breve, estratégico y motivacional en Español.
      
      Estructura tu respuesta:
      1. **Resumen Rápido**: Total a pagar pendiente vs Total pagado.
      2. **Estrategia de Prioridad**: Qué tarjeta pagar primero basándose en fechas de corte/pago próximas (asume que hoy es ${today.toDateString()}).
      3. **Alerta**: Si alguna tarjeta está cerca de su fecha límite.
      4. **Tip de Ahorro**: Un consejo general sobre el uso de crédito.

      Mantén el tono profesional pero amigable. No uses markdown complejo, solo negritas y listas.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "No se pudo generar el consejo en este momento.";
  } catch (error) {
    console.error("Error fetching financial advice:", error);
    return "Lo siento, hubo un error al conectar con el asistente financiero. Por favor intenta más tarde.";
  }
};