import React, { useState, useEffect } from 'react';
import { LayoutDashboard, Calendar as CalendarIcon, CreditCard, Plus } from 'lucide-react';
import { Dashboard } from './components/Dashboard';
import { CalendarView } from './components/CalendarView';
import { CardManager } from './components/CardManager';
import { FinancialAdvisor } from './components/FinancialAdvisor';
import { INITIAL_CARDS, INITIAL_PAYMENTS } from './constants';
import { CreditCard as CreditCardType, PaymentRecord, ViewState } from './types';

function App() {
  const [view, setView] = useState<ViewState>('dashboard');
  const [cards, setCards] = useState<CreditCardType[]>(INITIAL_CARDS);
  const [payments, setPayments] = useState<PaymentRecord[]>(INITIAL_PAYMENTS);
  const [currentDate, setCurrentDate] = useState(new Date());

  // Modal State for adding a payment manually (simplified for this demo)
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [newPaymentAmount, setNewPaymentAmount] = useState('');
  const [newPaymentCard, setNewPaymentCard] = useState('');

  // Persist functionality could be added here with useEffect and localStorage

  const handleMarkPaid = (id: string) => {
    setPayments(prev => prev.map(p => 
      p.id === id ? { ...p, isPaid: !p.isPaid } : p
    ));
  };

  const handleAddCard = (card: CreditCardType) => {
    setCards([...cards, card]);
  };

  const handleDeleteCard = (id: string) => {
    setCards(cards.filter(c => c.id !== id));
    setPayments(payments.filter(p => p.cardId !== id)); // Cleanup payments
  };

  const handleAddPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if(newPaymentCard && newPaymentAmount) {
      const newPayment: PaymentRecord = {
        id: crypto.randomUUID(),
        cardId: newPaymentCard,
        amount: parseFloat(newPaymentAmount),
        month: currentDate.getMonth(),
        year: currentDate.getFullYear(),
        isPaid: false
      };
      setPayments([...payments, newPayment]);
      setShowPaymentModal(false);
      setNewPaymentAmount('');
      setNewPaymentCard('');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Sidebar / Mobile Nav */}
      <nav className="fixed bottom-0 left-0 w-full bg-white border-t border-slate-200 z-50 md:relative md:w-64 md:h-screen md:border-r md:border-t-0 md:float-left flex md:flex-col justify-around md:justify-start p-2 md:p-6 shadow-sm">
        <div className="hidden md:block mb-10 px-2">
          <h1 className="text-2xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
            CrediPlan AI
          </h1>
          <p className="text-xs text-slate-400 mt-1">Gestión Inteligente</p>
        </div>

        <button 
          onClick={() => setView('dashboard')}
          className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'dashboard' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-500 hover:bg-slate-100'}`}
        >
          <LayoutDashboard className="w-6 h-6" />
          <span className="hidden md:inline">Dashboard</span>
        </button>

        <button 
          onClick={() => setView('calendar')}
          className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'calendar' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-500 hover:bg-slate-100'}`}
        >
          <CalendarIcon className="w-6 h-6" />
          <span className="hidden md:inline">Calendario</span>
        </button>

        <button 
          onClick={() => setView('cards')}
          className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'cards' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-500 hover:bg-slate-100'}`}
        >
          <CreditCard className="w-6 h-6" />
          <span className="hidden md:inline">Tarjetas</span>
        </button>
      </nav>

      {/* Main Content */}
      <main className="md:ml-64 p-4 md:p-8 pb-24 md:pb-8 max-w-7xl mx-auto">
        
        {/* Header Action */}
        <div className="flex justify-between items-center mb-8">
          <div className="md:hidden">
            <h1 className="text-xl font-bold text-indigo-900">CrediPlan AI</h1>
          </div>
          <div className="hidden md:block">
            <p className="text-slate-500">Bienvenido de nuevo</p>
          </div>
          <button 
            onClick={() => setShowPaymentModal(true)}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg shadow-md hover:shadow-lg transition-all flex items-center gap-2 text-sm font-medium"
          >
            <Plus className="w-4 h-4" />
            Registrar Monto
          </button>
        </div>

        {/* AI Section (Always visible on top of Dashboard and Calendar) */}
        {(view === 'dashboard' || view === 'calendar') && (
          <FinancialAdvisor cards={cards} payments={payments} />
        )}

        {/* Dynamic Views */}
        <div className="animate-in fade-in zoom-in-95 duration-300">
          {view === 'dashboard' && (
            <Dashboard 
              cards={cards} 
              payments={payments} 
              onMarkPaid={handleMarkPaid} 
            />
          )}
          {view === 'calendar' && (
            <CalendarView 
              cards={cards} 
              payments={payments}
              currentDate={currentDate}
              onDateChange={setCurrentDate}
            />
          )}
          {view === 'cards' && (
            <CardManager 
              cards={cards} 
              onAddCard={handleAddCard}
              onDeleteCard={handleDeleteCard}
            />
          )}
        </div>
      </main>

      {/* Add Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-slate-900 mb-4">Registrar monto a pagar</h3>
            <form onSubmit={handleAddPayment} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-1">Tarjeta</label>
                <select 
                  className="w-full rounded-lg border-slate-300 border p-2.5 bg-slate-50"
                  value={newPaymentCard}
                  onChange={(e) => setNewPaymentCard(e.target.value)}
                  required
                >
                  <option value="">Selecciona una tarjeta</option>
                  {cards.map(c => (
                    <option key={c.id} value={c.id}>{c.name} - {c.bank}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-1">Monto del corte</label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-400">$</span>
                  <input 
                    type="number" 
                    step="0.01"
                    className="w-full rounded-lg border-slate-300 border p-2.5 pl-8"
                    placeholder="0.00"
                    value={newPaymentAmount}
                    onChange={(e) => setNewPaymentAmount(e.target.value)}
                    required
                  />
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <button 
                  type="button" 
                  onClick={() => setShowPaymentModal(false)}
                  className="flex-1 px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancelar
                </button>
                <button 
                  type="submit" 
                  className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-medium"
                >
                  Guardar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;