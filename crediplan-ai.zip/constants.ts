import { CreditCard, PaymentRecord } from './types';

export const INITIAL_CARDS: CreditCard[] = [
  {
    id: '1',
    name: 'Platinum Rewards',
    bank: 'BBVA',
    limit: 50000,
    cutoffDay: 12,
    dueDay: 2,
    color: 'bg-blue-600'
  },
  {
    id: '2',
    name: 'Oro Travel',
    bank: 'Santander',
    limit: 35000,
    cutoffDay: 25,
    dueDay: 15,
    color: 'bg-red-600'
  },
  {
    id: '3',
    name: 'Costco Citibanamex',
    bank: 'Citibanamex',
    limit: 20000,
    cutoffDay: 5,
    dueDay: 25,
    color: 'bg-orange-500'
  }
];

// Generate some sample payments for the current month
const now = new Date();
const currentMonth = now.getMonth();
const currentYear = now.getFullYear();

export const INITIAL_PAYMENTS: PaymentRecord[] = [
  {
    id: '101',
    cardId: '1',
    amount: 4500.50,
    month: currentMonth,
    year: currentYear,
    isPaid: false,
  },
  {
    id: '102',
    cardId: '2',
    amount: 1200.00,
    month: currentMonth,
    year: currentYear,
    isPaid: true,
  },
  {
    id: '103',
    cardId: '3',
    amount: 8900.00,
    month: currentMonth,
    year: currentYear,
    isPaid: false,
  }
];