import React from 'react';
import { CreditCard, PaymentRecord } from '../types';
import { DollarSign, Calendar, CheckCircle2, AlertCircle } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface DashboardProps {
  cards: CreditCard[];
  payments: PaymentRecord[];
  onMarkPaid: (paymentId: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ cards, payments, onMarkPaid }) => {
  const totalDue = payments.reduce((acc, p) => acc + p.amount, 0);
  const totalPaid = payments.filter(p => p.isPaid).reduce((acc, p) => acc + p.amount, 0);
  const pendingAmount = totalDue - totalPaid;
  const pendingCount = payments.filter(p => !p.isPaid).length;

  // Prepare chart data
  const data = payments
    .filter(p => !p.isPaid)
    .map(p => {
      const card = cards.find(c => c.id === p.cardId);
      return {
        name: card?.name || 'Desconocida',
        value: p.amount,
        color: card?.color.replace('bg-', '') || 'gray', // Rough mapping for demo, usually need hex
        hex: '#6366f1' // Fallback
      };
    });
  
  // Custom colors for the chart based on Tailwind generic palette
  const CHART_COLORS = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6'];

  const upcomingPayments = payments
    .filter(p => !p.isPaid)
    .sort((a, b) => {
       // Simple sort logic: check due day vs today
       const cardA = cards.find(c => c.id === a.cardId);
       const cardB = cards.find(c => c.id === b.cardId);
       return (cardA?.dueDay || 0) - (cardB?.dueDay || 0);
    })
    .slice(0, 3);

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-100 text-indigo-600 rounded-xl">
              <DollarSign className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-slate-500 font-medium">Total Pendiente</p>
              <h3 className="text-2xl font-bold text-slate-900">${pendingAmount.toLocaleString('es-MX', { minimumFractionDigits: 2 })}</h3>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-emerald-100 text-emerald-600 rounded-xl">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-slate-500 font-medium">Pagado este Mes</p>
              <h3 className="text-2xl font-bold text-slate-900">${totalPaid.toLocaleString('es-MX', { minimumFractionDigits: 2 })}</h3>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-orange-100 text-orange-600 rounded-xl">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-slate-500 font-medium">Pagos Pendientes</p>
              <h3 className="text-2xl font-bold text-slate-900">{pendingCount}</h3>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart Section */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 min-h-[300px]">
          <h3 className="text-lg font-bold text-slate-800 mb-4">Distribución de Deuda</h3>
          {data.length > 0 ? (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {data.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value: number) => `$${value.toLocaleString()}`}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-64 w-full flex items-center justify-center text-slate-400">
              <p>No hay deudas pendientes 🎉</p>
            </div>
          )}
        </div>

        {/* Upcoming List */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-4">Próximos Vencimientos</h3>
          <div className="space-y-4">
            {upcomingPayments.length > 0 ? (
              upcomingPayments.map(payment => {
                const card = cards.find(c => c.id === payment.cardId);
                if (!card) return null;
                
                // Construct a date for display (assuming current month/year for simplicity in this view)
                const dueDate = new Date(payment.year, payment.month, card.dueDay);
                
                return (
                  <div key={payment.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-100 hover:border-indigo-100 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-10 rounded-full ${card.color}`}></div>
                      <div>
                        <p className="font-semibold text-slate-800">{card.name}</p>
                        <p className="text-xs text-slate-500">Vence: {format(dueDate, "d 'de' MMM", { locale: es })}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-slate-900">${payment.amount.toLocaleString()}</p>
                      <button 
                        onClick={() => onMarkPaid(payment.id)}
                        className="text-xs font-medium text-indigo-600 hover:text-indigo-800 mt-1"
                      >
                        Marcar Pagado
                      </button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="text-center py-8 text-slate-400">
                <CheckCircle2 className="w-12 h-12 mx-auto mb-2 opacity-20" />
                <p>Estás al día con tus pagos.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};