import React, { useState } from 'react';
import { Sparkles, RefreshCw, AlertCircle } from 'lucide-react';
import { CreditCard, PaymentRecord } from '../types';
import { getFinancialAdvice } from '../services/geminiService';

interface FinancialAdvisorProps {
  cards: CreditCard[];
  payments: PaymentRecord[];
}

export const FinancialAdvisor: React.FC<FinancialAdvisorProps> = ({ cards, payments }) => {
  const [advice, setAdvice] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGetAdvice = async () => {
    setLoading(true);
    const result = await getFinancialAdvice(cards, payments);
    setAdvice(result);
    setLoading(false);
  };

  return (
    <div className="bg-gradient-to-br from-indigo-900 to-purple-900 rounded-2xl p-6 text-white shadow-xl mb-6 border border-indigo-700/50">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-yellow-300" />
          Asistente Inteligente Gemini
        </h2>
        <button
          onClick={handleGetAdvice}
          disabled={loading}
          className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 disabled:opacity-50"
        >
          {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          {advice ? 'Actualizar Análisis' : 'Analizar Deudas'}
        </button>
      </div>

      {!advice && !loading && (
        <p className="text-indigo-200 text-sm">
          Solicita un análisis de tus pagos pendientes y fechas de corte para optimizar tu flujo de efectivo.
        </p>
      )}

      {loading && (
        <div className="animate-pulse space-y-3">
          <div className="h-4 bg-white/20 rounded w-3/4"></div>
          <div className="h-4 bg-white/20 rounded w-1/2"></div>
          <div className="h-4 bg-white/20 rounded w-full"></div>
        </div>
      )}

      {advice && !loading && (
        <div className="prose prose-invert prose-sm max-w-none bg-black/20 p-4 rounded-xl border border-white/10">
          <div className="whitespace-pre-line leading-relaxed">
            {advice}
          </div>
        </div>
      )}
    </div>
  );
};