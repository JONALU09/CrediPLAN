import React, { useState } from 'react';
import { CreditCard, BANK_COLORS } from '../types';
import { Plus, Trash2, CreditCard as CardIcon } from 'lucide-react';

interface CardManagerProps {
  cards: CreditCard[];
  onAddCard: (card: CreditCard) => void;
  onDeleteCard: (id: string) => void;
}

export const CardManager: React.FC<CardManagerProps> = ({ cards, onAddCard, onDeleteCard }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newCard, setNewCard] = useState<Partial<CreditCard>>({
    color: BANK_COLORS[0]
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCard.name && newCard.bank && newCard.limit && newCard.cutoffDay && newCard.dueDay) {
      onAddCard({
        id: crypto.randomUUID(),
        name: newCard.name,
        bank: newCard.bank,
        limit: Number(newCard.limit),
        cutoffDay: Number(newCard.cutoffDay),
        dueDay: Number(newCard.dueDay),
        color: newCard.color || BANK_COLORS[0]
      });
      setIsAdding(false);
      setNewCard({ color: BANK_COLORS[0] });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-slate-800">Mis Tarjetas</h2>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Nueva Tarjeta
        </button>
      </div>

      {isAdding && (
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl shadow-lg border border-indigo-100 animate-in fade-in slide-in-from-top-4">
          <h3 className="text-lg font-semibold mb-4 text-slate-700">Agregar Tarjeta</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Nombre (Alias)</label>
              <input 
                type="text" 
                required
                className="w-full rounded-lg border-slate-300 border p-2 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                placeholder="Ej. Oro Rewards"
                value={newCard.name || ''}
                onChange={e => setNewCard({...newCard, name: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Banco</label>
              <input 
                type="text" 
                required
                className="w-full rounded-lg border-slate-300 border p-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                placeholder="Ej. BBVA"
                value={newCard.bank || ''}
                onChange={e => setNewCard({...newCard, bank: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Límite de Crédito</label>
              <input 
                type="number" 
                required
                className="w-full rounded-lg border-slate-300 border p-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                placeholder="50000"
                value={newCard.limit || ''}
                onChange={e => setNewCard({...newCard, limit: Number(e.target.value)})}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-1">Día Corte</label>
                <input 
                  type="number" 
                  min="1" max="31"
                  required
                  className="w-full rounded-lg border-slate-300 border p-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={newCard.cutoffDay || ''}
                  onChange={e => setNewCard({...newCard, cutoffDay: Number(e.target.value)})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-1">Día Pago</label>
                <input 
                  type="number" 
                  min="1" max="31"
                  required
                  className="w-full rounded-lg border-slate-300 border p-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                  value={newCard.dueDay || ''}
                  onChange={e => setNewCard({...newCard, dueDay: Number(e.target.value)})}
                />
              </div>
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-600 mb-2">Color Identificador</label>
              <div className="flex gap-2 flex-wrap">
                {BANK_COLORS.map(color => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setNewCard({...newCard, color})}
                    className={`w-8 h-8 rounded-full ${color} ${newCard.color === color ? 'ring-2 ring-offset-2 ring-indigo-500' : ''}`}
                  />
                ))}
              </div>
            </div>
          </div>
          <div className="mt-6 flex justify-end gap-3">
            <button 
              type="button" 
              onClick={() => setIsAdding(false)}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg"
            >
              Cancelar
            </button>
            <button 
              type="submit" 
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
            >
              Guardar Tarjeta
            </button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {cards.map(card => (
          <div key={card.id} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 relative group overflow-hidden">
            <div className={`absolute top-0 left-0 w-2 h-full ${card.color}`}></div>
            <div className="flex justify-between items-start mb-4 pl-4">
              <div>
                <h3 className="font-bold text-slate-800 text-lg">{card.name}</h3>
                <p className="text-slate-500 text-sm">{card.bank}</p>
              </div>
              <div className="p-2 bg-slate-100 rounded-full">
                <CardIcon className="w-5 h-5 text-slate-600" />
              </div>
            </div>
            
            <div className="pl-4 space-y-2">
               <div className="flex justify-between text-sm">
                 <span className="text-slate-500">Límite:</span>
                 <span className="font-semibold text-slate-700">${card.limit.toLocaleString()}</span>
               </div>
               <div className="flex justify-between text-sm">
                 <span className="text-slate-500">Día de Corte:</span>
                 <span className="font-semibold text-slate-700">{card.cutoffDay}</span>
               </div>
               <div className="flex justify-between text-sm">
                 <span className="text-slate-500">Fecha Límite Pago:</span>
                 <span className="font-semibold text-red-600">{card.dueDay}</span>
               </div>
            </div>

            <button 
              onClick={() => onDeleteCard(card.id)}
              className="absolute top-4 right-4 p-2 text-red-400 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-50 rounded-full"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};